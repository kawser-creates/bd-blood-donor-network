# Hisab (হিসাব) - shared real-time version (Supabase)

Plain HTML / CSS / JavaScript. No build step. All data lives in one row of the
Supabase table `public.hisab_state` (column `state`, type jsonb), so every device
sees the same data and updates appear live.

Files: `index.html`, `style.css`, `script.js`, `setup.sql`, `README.md`

## Setup
1. **SQL.** Supabase dashboard -> SQL Editor -> paste `setup.sql` -> Run.
   It keeps your existing table and data, makes sure `id` is unique and row `id = 1`
   exists, turns on Row Level Security with policies for that one row, and enables Realtime.
   Any other keys already stored in `state` are preserved on every save.
   If your existing row uses another id, change `ROW_ID` at the top of `script.js`
   and the `id = 1` parts of the policies.
2. **Keys.** Dashboard -> Project Settings -> API. Copy the **Project URL** and the
   **Publishable key** (`sb_publishable_...`, or the legacy `anon` key).
3. **Paste them** into the two constants at the very top of `script.js`
   (`SUPABASE_URL`, `SUPABASE_KEY`). Never use the secret / service_role key: the
   app refuses to start if it detects one.
4. **Host** the folder on any static host (Netlify, Vercel, Firebase Hosting,
   GitHub Pages, Cloudflare Pages) or just open `index.html`.
5. In Supabase -> Authentication -> URL configuration nothing is needed (no login).

### Security note
There is no login, so anyone who has the website address can read and change the
shared data (the policies only limit access to this one row; they do not identify
people). Share the link only with your group. If you later need real protection,
add Supabase Auth and change the policies to `to authenticated`.

## How it behaves
- Starts with a loading screen and reads the cloud copy first. Nothing is written
  before that succeeds, so empty or old local data can never overwrite the cloud.
- Every change is saved to Supabase (batched, about 0.4 s). Other devices update
  automatically through Realtime. If you are typing, the screen refreshes when
  you leave the field.
- Two people saving at the same time: the app downloads the newer cloud version,
  merges both changes (adds, deletes and edits to items, members, saved accounts,
  payments; if both edit the same item, the person saving last wins) and retries.
- Offline or errors: a status pill at the top shows connected / saving / offline /
  error. Changes stay on the screen, retry automatically (up to 30 s apart) and
  are merged on reconnect. The browser warns before closing with unsaved changes.
- Old per-device data (`localStorage` key `hisab`) is never deleted. If the cloud
  is empty on first start, you are asked once whether to upload it.
- Language (Bengali / English) stays on each device (`localStorage` key `hisab_lg`).
- "Clear" buttons at the bottom now delete for everyone (the confirmation says so).

## Testing
1. Open the site on two devices (or two browser windows). The pill at the top should
   read "Connected".
2. Add members on device A -> they appear on device B within a second or two.
3. Add an expense item on B -> it appears on A without reload. Check the results box,
   friend folders, saved accounts, payments (Clear / partial) and language switch.
4. Conflict test: turn B offline (browser dev tools -> Network -> Offline), add an
   item on B, add a different item on A, turn B online. Both items should end up on
   both devices and a "merged" message appears.
5. Failure test: open the site with the Wi-Fi off. Expect the error screen with
   "Try again", not an empty app. Put a wrong key in `script.js` -> expect an error
   status, no data loss.
6. Supabase dashboard -> Table Editor -> `hisab_state`: the `state` column shows
   `m`, `t`, `h`, `p` and `rev` (increases with every save).
7. Reload with an empty `localStorage`: all data comes back from the cloud.

-- =====================================================================
-- Hisab - Supabase setup.  Run once in: Supabase dashboard -> SQL Editor.
-- Safe to run more than once. It never deletes or rewrites your data.
-- Your table: public.hisab_state (id integer, state jsonb, updated_at timestamptz)
-- =====================================================================

-- 1) Only creates the table if it does not exist (yours already does).
create table if not exists public.hisab_state (
  id         integer not null,
  state      jsonb   not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- 2) Make sure id is unique so there can only ever be one row with id = 1.
--    (If this line fails, you have duplicate ids: keep one row per id, then run again.)
create unique index if not exists hisab_state_id_uidx on public.hisab_state (id);

-- 3) The single shared row (added only if it is missing).
insert into public.hisab_state (id, state)
select 1, '{}'::jsonb
where not exists (select 1 from public.hisab_state where id = 1);

-- 4) Row Level Security: the publishable key can only read / insert / update row 1.
--    No delete, no other rows.
alter table public.hisab_state enable row level security;

drop policy if exists "hisab_select" on public.hisab_state;
drop policy if exists "hisab_insert" on public.hisab_state;
drop policy if exists "hisab_update" on public.hisab_state;

create policy "hisab_select" on public.hisab_state
  for select to anon, authenticated using (id = 1);
create policy "hisab_insert" on public.hisab_state
  for insert to anon, authenticated with check (id = 1);
create policy "hisab_update" on public.hisab_state
  for update to anon, authenticated using (id = 1) with check (id = 1);

-- 5) Realtime: send changes of this table to connected browsers.
do $$ begin
  alter publication supabase_realtime add table public.hisab_state;
exception when duplicate_object then null;
end $$;
